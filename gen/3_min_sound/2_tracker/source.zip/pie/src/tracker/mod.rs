use std::path::Path;

use crate::stamp::{FileStamp, FileStamper, OutputStamp, OutputStamper};
use crate::Task;

pub mod writing;
pub mod event;

/// Trait for tracking build events. Can be used to implement logging, event tracing, progress tracking, metrics, etc.
#[allow(unused_variables)]
pub trait Tracker<T: Task> {
  /// Start a new build.
  fn build_start(&mut self) {}
  /// A build has been completed.
  fn build_end(&mut self) {}

  /// A file at `path` has been required, using `stamper` to create `stamp`.
  fn required_file(&mut self, path: &Path, stamper: &FileStamper, stamp: &FileStamp) {}
  /// Require `task` using `stamper`.
  fn require_task(&mut self, task: &T, stamper: &OutputStamper) {}
  /// A `task` has been required, resulting in consistent `output`, using `stamper` to create `stamp`, and task 
  /// `was_executed`.
  fn required_task(&mut self, task: &T, output: &T::Output, stamper: &OutputStamper, stamp: &OutputStamp<T::Output>, was_executed: bool) {}

  /// Execute `task`.
  fn execute(&mut self, task: &T) {}
  /// A `task` has been executed, producing `output`.
  fn executed(&mut self, task: &T, output: &T::Output) {}
}

/// [`Tracker`] that does nothing.
#[derive(Copy, Clone, Debug)]
pub struct NoopTracker;
impl<T: Task> Tracker<T> for NoopTracker {}

/// [`Tracker`] that forwards build events to 2 trackers.
#[derive(Copy, Clone, Debug)]
pub struct CompositeTracker<A1, A2>(pub A1, pub A2);
impl<T: Task, A1: Tracker<T>, A2: Tracker<T>> Tracker<T> for CompositeTracker<A1, A2> {
  fn build_start(&mut self) {
    self.0.build_start();
    self.1.build_start();
  }
  fn build_end(&mut self) {
    self.0.build_end();
    self.1.build_end();
  }

  fn required_file(&mut self, path: &Path, stamper: &FileStamper, stamp: &FileStamp) {
    self.0.required_file(path, stamper, stamp);
    self.1.required_file(path, stamper, stamp);
  }
  fn require_task(&mut self, task: &T, stamper: &OutputStamper) {
    self.0.require_task(task, stamper);
    self.1.require_task(task, stamper);
  }
  fn required_task(&mut self, task: &T, output: &T::Output, stamper: &OutputStamper, stamp: &OutputStamp<T::Output>, was_executed: bool) {
    self.0.required_task(task, output, stamper, stamp, was_executed);
    self.1.required_task(task, output, stamper, stamp, was_executed);
  }

  fn execute(&mut self, task: &T) {
    self.0.execute(task);
    self.1.execute(task);
  }
  fn executed(&mut self, task: &T, output: &T::Output) {
    self.0.executed(task, output);
    self.1.executed(task, output);
  }
}
